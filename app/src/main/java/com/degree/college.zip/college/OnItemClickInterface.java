package com.degree100.college;

import android.view.View;

/**
 * Created by USER on 23-03-2018.
 */

public interface OnItemClickInterface  {
    void setonItemClickListener(View v, int position);
}
