package com.degree100.college.Pojo;

/**
 * Created by USER on 24-04-2018.
 */

public class More_pojo {
    private int image;
    private String name;

    public int getImage() {
        return image;
    }

    public More_pojo(int image, String name) {
        this.image = image;
        this.name = name;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
