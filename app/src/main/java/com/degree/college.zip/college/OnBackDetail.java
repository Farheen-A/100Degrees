package com.degree100.college;

/**
 * Created by USER on 03-05-2018.
 */

public interface OnBackDetail {
    void onBackDetail();
}
