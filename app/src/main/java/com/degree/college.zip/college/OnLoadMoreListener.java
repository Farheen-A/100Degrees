package com.degree100.college;

/**
 * Created by USER on 09-05-2018.
 */

public interface OnLoadMoreListener {
    void onLoadMore();
}
